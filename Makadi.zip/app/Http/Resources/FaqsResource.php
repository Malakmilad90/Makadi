<?php

namespace App\Http\Resources;

use App\Models\Admin\Faq;
use Illuminate\Http\Resources\Json\JsonResource;
use Intervention\Image\ImageManagerStatic as Image;
use kornrunner\Blurhash\Blurhash;
// use Bepsvpt\Blurhash\BlurHash;

class FaqsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */

    public function toArray($request)
    {
        $blurhash = null;
        if ($this->img) {
            $imgPath = Faq::POSTER_PATH . '/' . $this->img;
            $img = Image::make($imgPath);
            $width = $img->width();
            $height = $img->height();
            $pixels = [];
            for ($y = 0; $y < $height; ++$y) {
                $row = [];
                for ($x = 0; $x < $width; ++$x) {
                    $colors = $img->pickColor($x, $y);

                    $row[] = [$colors[0], $colors[1], $colors[2]];
                }
                $pixels[] = $row;
            }

            $components_x = 4;
            $components_y = 3;
            $blurhashdecode = Blurhash::encode($pixels, $components_x, $components_y);
            $imgpixels = Blurhash::decode($blurhashdecode, 300, 300);
            $image  = imagecreatetruecolor(300, 300);
            for ($y = 0; $y < 300; ++$y) {
                for ($x = 0; $x < 300; ++$x) {
                    [$r, $g, $b] = $imgpixels[$y][$x];
                    imagesetpixel($image, $x, $y, imagecolorallocate($image, $r, $g, $b));
                }
            }

            //  $img->blur(30);
            $img = Image::make($image);

            // $img->save();
            $encodedImg = $img->encode('jpg');
            if ($encodedImg) {
                $blurhash = base64_encode($encodedImg);
            } else {
                Log::error("Error encoding image for blurhash: " . $imgPath);
            }
        }
        return [
            'id' => $this->id,
            'question' => $this->question,
            'answer' => $this->answer,
            'img' => asset('upload/' . $this->img),
            'blurred_img' => asset('upload/blurredblurred_' . $this->img),
            'blurhash' => $blurhash,
        ];
    }
}
